package bean;

public class CurriculoBean {

    private int id;

    private String resumo;

    private String expProfissional;

    private String forBasica;

    private String FormMedio;
    
    private String idPessoa;

    public String getIdPessoa() {
        return idPessoa;
    }

    public void setIdPessoa(String idPessoa) {
        this.idPessoa = idPessoa;
    }
    
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getResumo() {
        return resumo;
    }

    public void setResumo(String resumo) {
        this.resumo = resumo;
    }

    public String getExpProfissional() {
        return expProfissional;
    }

    public void setExpProfissional(String expProfissional) {
        this.expProfissional = expProfissional;
    }

    public String getForBasica() {
        return forBasica;
    }

    public void setForBasica(String forBasica) {
        this.forBasica = forBasica;
    }

    public String getFormMedio() {
        return FormMedio;
    }

    public void setFormMedio(String FormMedio) {
        this.FormMedio = FormMedio;
    }
    
    
}
