package bean;

public class TipoFormacaoBean {

    private String id_Tipo;

    private String descricao;

    public String getId_Tipo() {
        return id_Tipo;
    }

    public void setId_Tipo(String id_Tipo) {
        this.id_Tipo = id_Tipo;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }
    
    
}
