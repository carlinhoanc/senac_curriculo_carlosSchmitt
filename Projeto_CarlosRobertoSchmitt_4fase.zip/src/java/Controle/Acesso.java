/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controle;

/**
 *
 * @author CarlosRoberto
 */
public class Acesso {
    
    
    /**
     * acesso ao sistema como administrador dele
     * @return 
     */
    public static boolean acessoAdmin(){
        
        return false;
    }
    
    
    /**
     * Acesso ao sistema para poder editar o curriculo
     * @return 
     */
    public static boolean acessoSistema(){
        
        return  false;
    }
    
    
}
